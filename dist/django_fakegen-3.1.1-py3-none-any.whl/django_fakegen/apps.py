from django.apps import AppConfig

class DjangoFakegenConfig(AppConfig):
    name = 'django_fakegen' 
    verbose_name = "Django Fake Data Generator"
