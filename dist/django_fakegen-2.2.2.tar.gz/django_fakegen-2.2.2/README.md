# django-fakegen

A Django package for generating fake data for your models. 